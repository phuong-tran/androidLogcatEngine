/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: /Users/phuongnamtran/Library/Android/sdk/build-tools/35.0.0/aidl -p/Users/phuongnamtran/Library/Android/sdk/platforms/android-36/framework.aidl -o/Users/phuongnamtran/android_projects/androidLogcatEngine/core/build/generated/aidl_source_output_dir/release/out -I/Users/phuongnamtran/android_projects/androidLogcatEngine/core/src/main/aidl -I/Users/phuongnamtran/android_projects/androidLogcatEngine/core/src/release/aidl -d/var/folders/zq/4y28r70d1bs6h5vkmgrm5cm40000gn/T/aidl17613705160816096765.d /Users/phuongnamtran/android_projects/androidLogcatEngine/core/src/main/aidl/com/core/logcat/capture/ILogControl.aidl
 */
package com.core.logcat.capture;
public interface ILogControl extends android.os.IInterface
{
  /** Default implementation for ILogControl. */
  public static class Default implements com.core.logcat.capture.ILogControl
  {
    @Override public void updateLiteral(java.lang.String text) throws android.os.RemoteException
    {
    }
    @Override public void startLogging(java.lang.String tags, java.lang.String regex) throws android.os.RemoteException
    {
    }
    @Override public void updateFilters(java.lang.String tags, java.lang.String regex) throws android.os.RemoteException
    {
    }
    @Override public void stopLogging() throws android.os.RemoteException
    {
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements com.core.logcat.capture.ILogControl
  {
    /** Construct the stub at attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an com.core.logcat.capture.ILogControl interface,
     * generating a proxy if needed.
     */
    public static com.core.logcat.capture.ILogControl asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof com.core.logcat.capture.ILogControl))) {
        return ((com.core.logcat.capture.ILogControl)iin);
      }
      return new com.core.logcat.capture.ILogControl.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_updateLiteral:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          this.updateLiteral(_arg0);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_startLogging:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          java.lang.String _arg1;
          _arg1 = data.readString();
          this.startLogging(_arg0, _arg1);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_updateFilters:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          java.lang.String _arg1;
          _arg1 = data.readString();
          this.updateFilters(_arg0, _arg1);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_stopLogging:
        {
          this.stopLogging();
          reply.writeNoException();
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements com.core.logcat.capture.ILogControl
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      @Override public void updateLiteral(java.lang.String text) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(text);
          boolean _status = mRemote.transact(Stub.TRANSACTION_updateLiteral, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void startLogging(java.lang.String tags, java.lang.String regex) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(tags);
          _data.writeString(regex);
          boolean _status = mRemote.transact(Stub.TRANSACTION_startLogging, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void updateFilters(java.lang.String tags, java.lang.String regex) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(tags);
          _data.writeString(regex);
          boolean _status = mRemote.transact(Stub.TRANSACTION_updateFilters, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void stopLogging() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_stopLogging, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
    }
    static final int TRANSACTION_updateLiteral = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
    static final int TRANSACTION_startLogging = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
    static final int TRANSACTION_updateFilters = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
    static final int TRANSACTION_stopLogging = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
  }
  /** @hide */
  public static final java.lang.String DESCRIPTOR = "com.core.logcat.capture.ILogControl";
  public void updateLiteral(java.lang.String text) throws android.os.RemoteException;
  public void startLogging(java.lang.String tags, java.lang.String regex) throws android.os.RemoteException;
  public void updateFilters(java.lang.String tags, java.lang.String regex) throws android.os.RemoteException;
  public void stopLogging() throws android.os.RemoteException;
}
